import boto3

def run_tests():
    print ("run_tests")
    body = {'tests_passed' : True}
    
    return body